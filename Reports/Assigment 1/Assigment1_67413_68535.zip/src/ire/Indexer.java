/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ire;

/**
 *
 * @author Bruno Silva <brunomiguelsilva@ua.pt>
 */
public class Indexer {
    
    private Index index;
    
    public Indexer(){
        index = new Index();
    }
    
    public Indexer(Index idx){
        index = idx;
    }
    
    public void indexDocument(Document doc){
        
    }
}
