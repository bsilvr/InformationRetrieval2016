/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ire;

/**
 *
 * @author Bruno Silva <brunomiguelsilva@ua.pt>
 */
public class Tokenizer {
    
    
    public void tokenize(Document doc){
        // le o documento
        // Escreve para o ficheiro tokenizado
    }
        
    public String transform(String doc){
        // Converte tudo para minusculas, steamming, stopword filter, etc
        // stopwords em primeiro lugar senao siglas podem ser ser eliminadas.
        return null;
    }
}
